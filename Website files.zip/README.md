# Academic Site Template

Static HTML/CSS site (no build step, no dependencies besides Google Fonts CDN).

## Structure
```
index.html      About
research.html   Research
teaching.html   Teaching
service.html    Service
assets/style.css
assets/avatar-placeholder.svg
```

## Editing
Open each `.html` file and replace anything in `[brackets]`. Duplicate the
marked repeating blocks (`pub-entry`, `ledger-row`, `ledger-group`, `<li>`)
for additional papers/courses/service items. Colors and type are set once in
`assets/style.css`.

## Deploy to GitHub Pages

1. Create a new repository on GitHub (e.g. `yourname.github.io` for a
   user site at the root domain, or any name for a project site).
2. From this folder, run:
   ```bash
   git init
   git add .
   git commit -m "Initial site"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```
3. On GitHub: repo → **Settings** → **Pages** → under "Build and
   deployment," set **Source** to `Deploy from a branch`, branch `main`,
   folder `/ (root)` → **Save**.
4. The site will be live within a few minutes at:
   - `https://YOUR_USERNAME.github.io/` (if the repo is named
     `YOUR_USERNAME.github.io`), or
   - `https://YOUR_USERNAME.github.io/YOUR_REPO/` (any other repo name).

No further configuration is required — GitHub Pages serves the static
files directly.
